/**
 * 
 */
/**
 * 
 */
module LAB3 {
}