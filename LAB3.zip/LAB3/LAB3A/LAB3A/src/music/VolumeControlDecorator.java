package music;

public class VolumeControlDecorator extends BaseMusicPlayer {
    public VolumeControlDecorator(MusicService musicService) {
        super(musicService);
    }

    public void adjustVolume(int volumeLevel) {
        System.out.println("Volume level set to: " + volumeLevel);
    }
}

