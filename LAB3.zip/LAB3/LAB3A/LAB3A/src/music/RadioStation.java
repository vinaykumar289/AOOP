package music;
public class RadioStation {
	
    public void startBroadcast() {
        System.out.println("Starting radio broadcast...");
    }

    public void stopBroadcast() {
        System.out.println("Stopping radio broadcast...");
    }
}
