package music;

public abstract class BaseMusicPlayer implements MusicService {
    protected MusicService musicService;

    public BaseMusicPlayer(MusicService musicService) {
        this.musicService = musicService;
    }

    @Override
    public void play() {
        musicService.play();
    }

    @Override
    public void stop() {
        musicService.stop();
    }

    @Override
    public void pause() {
        musicService.pause();
    }

    @Override
    public void resume() {
        musicService.resume();
    }
}

