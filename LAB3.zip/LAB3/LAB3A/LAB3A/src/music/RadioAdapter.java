package music;

public class RadioAdapter implements MusicService {
    private RadioStation radioStation;

    public RadioAdapter(RadioStation radioStation) {
        this.radioStation = radioStation;
    }

    @Override
    public void play() {
        radioStation.startBroadcast();
    }

    @Override
    public void stop() {
        radioStation.stopBroadcast();
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }
}
