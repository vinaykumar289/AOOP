package music;

public class OnlineStreamAdapter implements MusicService {
    private OnlineStreamingService streamingService;

    public OnlineStreamAdapter(OnlineStreamingService streamingService) {
        this.streamingService = streamingService;
    }

    @Override
    public void play() {
        streamingService.startStream();
    }

    @Override
    public void stop() {
        streamingService.endStream();
    }

    @Override
    public void pause() {
        streamingService.pauseStream();
    }

    @Override
    public void resume() {
        streamingService.resumeStream();
    }
}

