package music;

public class OnlineStreamingService {
    public void startStream() {
        System.out.println("Starting online stream...");
    }

    public void endStream() {
        System.out.println("Ending online stream...");
    }

    public void pauseStream() {
        System.out.println("Pausing online stream...");
    }

    public void resumeStream() {
        System.out.println("Resuming online stream...");
    }
}

