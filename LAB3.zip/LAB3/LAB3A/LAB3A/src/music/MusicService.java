package music;

public interface MusicService {
    void play();
    void stop();
    void pause();
    void resume();
}

