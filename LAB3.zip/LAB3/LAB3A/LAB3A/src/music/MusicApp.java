package music;

public class MusicApp {
    public static void main(String[] args) {
        
        LocalFile localFile = new LocalFile();
        OnlineStreamingService streamingService = new OnlineStreamingService();
        RadioStation radioStation = new RadioStation();

        MusicService localFileService = new LocalFileAdapter(localFile);
        MusicService onlineStreamService = new OnlineStreamAdapter(streamingService);
        MusicService radioService = new RadioAdapter(radioStation);

        MusicService equalizedLocalFile = new EqualizerDecorator(localFileService);
        MusicService volumeControlledStream = new VolumeControlDecorator(
            new EqualizerDecorator(onlineStreamService)
        );

        equalizedLocalFile.play();
        ((EqualizerDecorator) equalizedLocalFile).setEqualizerSettings("Rock");

        volumeControlledStream.play();
        ((VolumeControlDecorator) volumeControlledStream).adjustVolume(75);
     
        if (volumeControlledStream instanceof EqualizerDecorator) {
            ((EqualizerDecorator) volumeControlledStream).setEqualizerSettings("Pop");
        }

        radioService.play();
    }
}

