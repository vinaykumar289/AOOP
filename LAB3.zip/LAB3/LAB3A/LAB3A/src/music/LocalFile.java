package music;

public class LocalFile {
    public void playFile() {
        System.out.println("Playing local file...");
    }

    public void stopFile() {
        System.out.println("Stopping local file...");
    }

    public void pauseFile() {
        System.out.println("Pausing local file...");
    }

    public void resumeFile() {
        System.out.println("Resuming local file...");
    }
}

