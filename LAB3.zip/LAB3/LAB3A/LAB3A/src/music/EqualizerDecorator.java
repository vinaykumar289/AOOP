package music;

public class EqualizerDecorator extends BaseMusicPlayer {
    public EqualizerDecorator(MusicService musicService) {
        super(musicService);
    }

    public void setEqualizerSettings(String settings) {
        System.out.println("Equalizer settings applied: " + settings);
    }
}

