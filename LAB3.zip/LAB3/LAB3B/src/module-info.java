/**
 * 
 */
/**
 * 
 */
module LAB3B {
}