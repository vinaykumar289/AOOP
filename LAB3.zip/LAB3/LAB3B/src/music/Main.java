package music;

public class Main {
    public static void main(String[] args) {
        
        MusicSource localFile = new LocalFileAdapter("Cold song.mp3");
        MusicSource onlineStream = new OnlineStreamingAdapter("http://example.com/stream");
        MusicSource radioStation = new RadioStationAdapter("Classic Rock");

        MusicPlayback playback = new StandardPlayback(localFile);

        MusicPlayback volumeControlledPlayback = new VolumeControlDecorator(playback, 75);

        MusicPlayback equalizedPlayback = new EqualizerDecorator(volumeControlledPlayback, "Rock");

        equalizedPlayback.play();
    }
}
