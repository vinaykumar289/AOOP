package music;

public abstract class PlaybackDecorator extends MusicPlayback {
    protected MusicPlayback decoratedPlayback;

    public PlaybackDecorator(MusicPlayback decoratedPlayback) {
        super(decoratedPlayback.source);
        this.decoratedPlayback = decoratedPlayback;
    }

    @Override
    public void play() {
        decoratedPlayback.play();
    }

    @Override
    public void pause() {
        decoratedPlayback.pause();
    }

    @Override
    public void stop() {
        decoratedPlayback.stop();
    }
}

