package music;

public class StandardPlayback extends MusicPlayback {

    public StandardPlayback(MusicSource source) {
        super(source);
    }

    @Override
    public void play() {
        source.play();
    }

    @Override
    public void pause() {
        source.pause();
    }

    @Override
    public void stop() {
        source.stop();
    }
}

