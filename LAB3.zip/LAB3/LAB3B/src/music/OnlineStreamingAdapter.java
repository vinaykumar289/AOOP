package music;

public class OnlineStreamingAdapter implements MusicSource {
    private String streamUrl;

    public OnlineStreamingAdapter(String streamUrl) {
        this.streamUrl = streamUrl;
    }

    @Override
    public void play() {
        System.out.println("Playing online stream: " + streamUrl);
    }

    @Override
    public void pause() {
        System.out.println("Pausing online stream: " + streamUrl);
    }

    @Override
    public void stop() {
        System.out.println("Stopping online stream: " + streamUrl);
    }
}

