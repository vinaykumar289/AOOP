package music;

public class VolumeControlDecorator extends PlaybackDecorator {
    private int volumeLevel;

    public VolumeControlDecorator(MusicPlayback decoratedPlayback, int volumeLevel) {
        super(decoratedPlayback);
        this.volumeLevel = volumeLevel;
    }

    public void setVolume(int volumeLevel) {
        this.volumeLevel = volumeLevel;
        System.out.println("Volume set to: " + volumeLevel);
    }

    @Override
    public void play() {
        super.play();
        System.out.println("Volume level is: " + volumeLevel);
    }
}
