package music;

public class EqualizerDecorator extends PlaybackDecorator {
    private String equalizerSetting;

    public EqualizerDecorator(MusicPlayback decoratedPlayback, String equalizerSetting) {
        super(decoratedPlayback);
        this.equalizerSetting = equalizerSetting;
    }

    public void setEqualizer(String equalizerSetting) {
        this.equalizerSetting = equalizerSetting;
        System.out.println("Equalizer set to: " + equalizerSetting);
    }

    @Override
    public void play() {
        super.play();
        System.out.println("Equalizer setting is: " + equalizerSetting);
    }
}

