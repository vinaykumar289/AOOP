package music;

public abstract class MusicPlayback {
    protected MusicSource source;

    public MusicPlayback(MusicSource source) {
        this.source = source;
    }

    public abstract void play();
    public abstract void pause();
    public abstract void stop();
}

