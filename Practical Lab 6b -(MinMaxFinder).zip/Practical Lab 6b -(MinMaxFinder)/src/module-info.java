/**
 * 
 */
/**
 * 
 */
module MinMaxFinder {
}