package com.example.utils;

// Define a generic interface for finding maximum and minimum values
public interface MinMaxFinder<T extends Comparable<T>> {
    T findMax(T[] array);
    T findMin(T[] array);
}
