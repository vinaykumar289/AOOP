package com.example.utils;

public class Main {
    public static void main(String[] args) {
        
        Integer[] intArray = {1, 3, 5, 7, 9};
        GenericMinMaxFinder<Integer> intFinder = new GenericMinMaxFinder<>();
        System.out.println("Integer Array - Max: " + intFinder.findMax(intArray));
        System.out.println("Integer Array - Min: " + intFinder.findMin(intArray));
        String[] strArray = {"apple", "orange", "banana", "pear"};
        GenericMinMaxFinder<String> strFinder = new GenericMinMaxFinder<>();
        System.out.println("String Array - Max: " + strFinder.findMax(strArray));
        System.out.println("String Array - Min: " + strFinder.findMin(strArray));
        Character[] charArray = {'a', 'z', 'm', 'r'};
        GenericMinMaxFinder<Character> charFinder = new GenericMinMaxFinder<>();
        System.out.println("Character Array - Max: " + charFinder.findMax(charArray));
        System.out.println("Character Array - Min: " + charFinder.findMin(charArray));
        Float[] floatArray = {1.1f, 2.2f, 3.3f, 0.4f};
        GenericMinMaxFinder<Float> floatFinder = new GenericMinMaxFinder<>();
        System.out.println("Float Array - Max: " + floatFinder.findMax(floatArray));
        System.out.println("Float Array - Min: " + floatFinder.findMin(floatArray));
    }
}
