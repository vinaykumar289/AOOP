// ConcreteBroker.java
public class ConcreteBroker implements Broker {
    private String brokerName;

    public ConcreteBroker(String name) {
        this.brokerName = name;
    }

    @Override
    public void update(Stock stock) {
        System.out.println("Broker " + brokerName + " notified. " + stock.getSymbol() +
            " is now $" + stock.getPrice());
    }
}
