// Broker.java
public interface Broker {
    void update(Stock stock);
}
