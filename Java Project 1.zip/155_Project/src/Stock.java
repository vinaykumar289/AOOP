// Stock.java
import java.util.ArrayList;
import java.util.List;

public class Stock {
    private String symbol;
    private double price;
    private List<Broker> brokers = new ArrayList<>();

    public Stock(String symbol, double initialPrice) {
        this.symbol = symbol;
        this.price = initialPrice;
    }

    // Method to add brokers to the notification list
    public void addBroker(Broker broker) {
        brokers.add(broker);
    }

    // Method to remove brokers from the notification list
    public void removeBroker(Broker broker) {
        brokers.remove(broker);
    }

    // Method to update the stock price and notify brokers
    public void setPrice(double newPrice) {
        this.price = newPrice;
        notifyBrokers();
    }

    public double getPrice() {
        return price;
    }

    private void notifyBrokers() {
        for (Broker broker : brokers) {
            broker.update(this);
        }
    }

    public String getSymbol() {
        return symbol;
    }
}
