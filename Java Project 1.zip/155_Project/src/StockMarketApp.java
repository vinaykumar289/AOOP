// StockMarketApp.java
public class StockMarketApp {
    public static void main(String[] args) {
        // Create a stock
        Stock googleStock = new Stock("GOOGL", 1500.00);

        // Create brokers
        Broker broker1 = new ConcreteBroker("Broker1");
        Broker broker2 = new ConcreteBroker("Broker2");

        // Add brokers to the stock's notification list
        googleStock.addBroker(broker1);
        googleStock.addBroker(broker2);

        // Change the stock price
        googleStock.setPrice(1520.50);
        googleStock.setPrice(1535.75);

        // Remove a broker and change the price again
        googleStock.removeBroker(broker1);
        googleStock.setPrice(1550.00);
    }
}
