public class ShoppingCartApp {
    public static void main(String[] args) {
        ShoppingCart cart = new ShoppingCart();

        // Add items to the cart
        cart.addItem("Laptop", 1200.00, 1);
        cart.addItem("Headphones", 150.00, 2);
        cart.addItem("Keyboard", 50.00, 1);

        // Display cart items
        System.out.println("Items in your cart:");
        cart.displayItems();

        // Calculate and display total before discount
        double total = cart.calculateTotal();
        System.out.println("\nTotal before discount: $" + total);

        // Apply a discount using a lambda expression
        double discountedTotal = cart.applyDiscount(totalAmount -> totalAmount * 0.90);  // 10% discount
        System.out.println("Total after 10% discount: $" + discountedTotal);

        // Remove items using a lambda expression (remove items with price less than $100)
        cart.removeItems(item -> item.getPrice() < 100);

        // Display updated cart items after removing
        System.out.println("\nItems in your cart after removal:");
        cart.displayItems();

        // Calculate total after removal
        total = cart.calculateTotal();
        System.out.println("Final total after removal: $" + total);
    }
}
