import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ShoppingCart {
    private List<CartItem> cartItems = new ArrayList<>();

    // Nested class representing items in the cart
    public class CartItem {
        private String itemName;
        private double price;
        private int quantity;

        public CartItem(String itemName, double price, int quantity) {
            this.itemName = itemName;
            this.price = price;
            this.quantity = quantity;
        }

        public double getTotalPrice() {
            return price * quantity;
        }

        @Override
        public String toString() {
            return quantity + " x " + itemName + " @ $" + price + " each. Total: $" + getTotalPrice();
        }

        public String getItemName() {
            return itemName;
        }

        public double getPrice() {
            return price;
        }

        public int getQuantity() {
            return quantity;
        }
    }

    // Add item to the cart
    public void addItem(String itemName, double price, int quantity) {
        cartItems.add(new CartItem(itemName, price, quantity));
    }

    // Display items in the cart
    public void displayItems() {
        if (cartItems.isEmpty()) {
            System.out.println("Shopping cart is empty.");
        } else {
            for (CartItem item : cartItems) {
                System.out.println(item);
            }
        }
    }

    // Calculate total cart value
    public double calculateTotal() {
        return cartItems.stream().mapToDouble(CartItem::getTotalPrice).sum();
    }

    // Apply discount strategy using lambda
    public double applyDiscount(DiscountStrategy discountStrategy) {
        double total = calculateTotal();
        return discountStrategy.apply(total);
    }

    // Remove items based on a condition using lambda
    public void removeItems(Predicate<CartItem> condition) {
        cartItems = cartItems.stream().filter(condition.negate()).collect(Collectors.toList());
    }

    // Functional interface for discount strategy
    @FunctionalInterface
    public interface DiscountStrategy {
        double apply(double total);
    }
}
