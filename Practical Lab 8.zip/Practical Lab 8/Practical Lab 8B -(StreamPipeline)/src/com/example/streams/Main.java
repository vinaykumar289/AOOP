package com.example.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
 List<Integer> numbers = new ArrayList<>();
 numbers.add(1);
 numbers.add(2);
 numbers.add(3);
 numbers.add(4);
 numbers.add(5);
 numbers.add(6);
 System.out.println("Original list: " + numbers);
 List<Integer> processedNumbers = numbers.stream()
.filter(n -> n % 2 == 0)  
.map(n -> n * 2) 
.collect(Collectors.toList()); 
System.out.println("Processed list: " + processedNumbers);
    }
}
